package domain;

public enum VagaStatus {
	DISPONIVEL, OCUPADA, INDISPONIVEL
}
