import { Veiculo } from '../domain/veiculo';

export class Cliente {
  id: number;
  nome: string;
  cpf: string;
  telefone: string;
  veiculos: Veiculo[];
}
