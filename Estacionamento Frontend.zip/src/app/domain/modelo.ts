import { Veiculo } from '../domain/veiculo';

export class Modelo {
  id: number;
  nome: string;
  veiculos: Veiculo[];
}
