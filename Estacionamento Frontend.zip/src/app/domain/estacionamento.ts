import { Veiculo } from '../domain/veiculo';
import { Vaga } from '../domain/vaga';

export class Estacionamento {
  id: number;
  entrada: Date;
  saida: Date;
  valorPago: number;
  veiculo: Veiculo;
  vaga: Vaga;
}
