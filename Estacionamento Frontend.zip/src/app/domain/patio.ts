import { Vaga } from '../domain/vaga';

export class Patio {
  id: number;
  descricao: string;
  taxaHora: number;
  vagas: Vaga[];
  vagasTransient: Vaga[];
}
