import { Veiculo } from '../domain/veiculo';

export class Cor {
  id: number;
  nome: string;
  veiculos: Veiculo[];
}
