import { Patio } from '../domain/patio';
import { VagaStatus } from '../domain/vaga-status';
import { Estacionamento } from '../domain/estacionamento';

export class Vaga {
  id: number;
  numero: number;
  patio: Patio;
  status: VagaStatus;
  ultimaEstacionada: Estacionamento;
}
