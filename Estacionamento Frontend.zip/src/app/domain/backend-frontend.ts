
export class BackendFrontend {
  success: Boolean;
  message: string;
  object: any;
  list: any;
}
