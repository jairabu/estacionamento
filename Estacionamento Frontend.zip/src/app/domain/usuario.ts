
export class Usuario {
  id: number;
  login: string;
  senha: string;
  nome: string;
  telefone: string;
}
