import { Cliente } from '../domain/cliente';
import { Modelo } from '../domain/modelo';
import { Cor } from '../domain/cor';
import { Estacionamento } from '../domain/estacionamento';

export class Veiculo {
  id: number;
  placa: string;
  cliente: Cliente;
  modelo: Modelo;
  cor: Cor;
  estacionadas: Estacionamento[];
}
