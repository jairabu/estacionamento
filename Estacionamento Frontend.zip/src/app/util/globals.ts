import { MatSnackBar } from '@angular/material';
import { Usuario } from '../domain/usuario';
import { UsuarioService } from '../service/usuario.service';
import {
  Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized
} from '@angular/router';

class Global {
  static urlService:string = "//localhost:8080";
  //static urlService:string = "http://www.integradados.com.br";

  static usuarioLogado: Usuario;

  static getUsuarioLogado(): Usuario {
    Global.usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
    return Global.usuarioLogado;
  }

  static isUsuarioLogado(): boolean {
    var usuario: Usuario = Global.getUsuarioLogado();
    if(usuario) {
      return true;
    }
    else {
      return false;
    }
  }

  static abrirSnackBarDuration(snackBar: MatSnackBar, message: string, duration:number = 3000, action: string = "Fechar") {
    snackBar.open(message, action, {
      duration: duration,
    });
  }

  static abrirSnackBar(snackBar: MatSnackBar, message: string, action: string = "Fechar") {
    snackBar.open(message, action, {
      duration: 3000,
    });
  }

  static entrar(
    usuarioService: UsuarioService,
    snackBar: MatSnackBar,
    router: Router,
    loading: any,
    login: string,
    senha: string
  ): void {
    loading.value = true;
    usuarioService.login(login, senha).subscribe (bf => {
      if(bf && bf.success) {
        localStorage.setItem('usuarioLogado', JSON.stringify(bf.object));
        router.navigate(['/dash']);
      }

      if(bf.message) {
        Global.abrirSnackBar(snackBar, bf.message);
      }
      else {
        Global.abrirSnackBar(snackBar, "Erro desconhecido ao fazer login!");
      }
      loading.value = false;
    });
  }

  static sair(snackBar: MatSnackBar) {
    // Se necessário pode-se salvar a data de logout por exemplo
    //this.usuarioService.logout(Global.getUsuarioLogado()).subscribe (login => {
    localStorage.removeItem('usuarioLogado');
    //});
    Global.abrirSnackBar(snackBar, "Usuário deslogado!");
  }
}

export {
  Global
}
