import {
  Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import {
  MatSort, MatPaginator, MatTableDataSource, MatTabChangeEvent, MatSnackBar
} from '@angular/material';
import { FormControl } from '@angular/forms';
import { Observable, Subject, pipe, of, from } from 'rxjs';
import { map, filter, scan } from 'rxjs/operators';
import { NgForm } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';

import { Global } from '../util/globals';
import { BackendFrontend } from '../domain/backend-frontend';

export class GenericComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  entityToCopy: any;
  columnsDesktop = ['id', 'nome'];
  columnsMobile = ['id', 'nome'];
  entityService: any;
  snackBar: MatSnackBar;

  Global = Global;
  entity: any;
  entities = new MatTableDataSource<any>();
  columns =  this.columnsDesktop;
  loading = false;
  currentTab = 0;

  constructor () {

  }

  onResize(event) {
    this.adjustColumns(event.target.innerWidth);
  }

  ngOnInit() {

  }

  ngAfterContentInit() {
    this.adjustColumns(window.innerWidth);
  }

  ngAfterViewInit() {
    this.entities.paginator = this.paginator;
    this.entities.sort = this.sort;
  }

  adjustColumns(width: number) {
    this.columns = width<=500 ? this.columnsMobile : this.columnsDesktop;
  }

  applyFilter(filterValue: string) {
    if(filterValue) {
      this.entities.filter = filterValue.trim().toLowerCase();
    }
  }

  changeTab(tabChangeEvent: MatTabChangeEvent) {
    this.currentTab = tabChangeEvent.index;
  }

  loadAll(): void {
    this.columnsMobile = this.columnsDesktop.slice(0, 2);
    this.currentTab = 0;
    this.entity = this.deepCopy(this.entityToCopy);
    this.findAll();
    this.loadAllAfter();
  }

  // Método que pode ser chamado por subclasse após superclasse salvar entidade
  loadAllAfter():void { }

  select(row): void {
    this.entity = row;
    this.currentTab = 1;
  }

  cancel() {
    this.loadAll();
  }

  getListFromBF(bf: BackendFrontend): any {
    if(bf && bf.success) {
      return bf.list;
    }
    if(bf.message) {
      Global.abrirSnackBar(this.snackBar, bf.message);
      return null;
    }
  }

  findAll(): void {
    this.loading = true;
    this.entityService.findAll().subscribe (bf => {
      this.loading = false;
      this.entities.data = this.getListFromBF(bf);
      this.findAllAfter();
    });
  }

  findAllAfter() {
  }

  save(): void {
    this.loading = true;
    this.entityService.save(this.entity).subscribe(bf => {
      this.loading = false;
      if(bf.success) {
        this.loadAll();
      }
      if(bf.message) {
        Global.abrirSnackBar(this.snackBar, bf.message);
      }
      else {
        Global.abrirSnackBar(this.snackBar, "Erro desconhecido ao fazer persistência!");
      }
    });
  }

  update(): void {
    this.loading = true;
    this.entityService.update(this.entity).subscribe(bf => {
      this.loading = false;
      if(bf.message) {
        Global.abrirSnackBar(this.snackBar, bf.message);
      }
      else {
        Global.abrirSnackBar(this.snackBar, "Erro desconhecido ao fazer atualização!");
      }
      this.loadAll();
    });
  }

  delete(): void {
    this.loading = true;
    this.entityService.delete(this.entity).subscribe(bf => {
      if(bf.message) {
        Global.abrirSnackBar(this.snackBar, bf.message);
      }
      else {
        Global.abrirSnackBar(this.snackBar, "Erro desconhecido ao fazer remoção!");
      }
      this.loadAll();
    });
  }

  deepCopy(obj) {
    var copy;
    // Handle the 3 simple types, and null or undefined
    if (null == obj || "object" != typeof obj) return obj;
    // Handle Date
    if (obj instanceof Date) {
        copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }
    // Handle Array
    if (obj instanceof Array) {
        copy = [];
        for (var i = 0, len = obj.length; i < len; i++) {
            copy[i] = this.deepCopy(obj[i]);
        }
        return copy;
    }
    // Handle Object
    if (obj instanceof Object) {
        copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr)) copy[attr] = this.deepCopy(obj[attr]);
        }
        return copy;
    }
    throw new Error("generic.component: Não é possivel efetuar cópia de objeto.");
  }
}
