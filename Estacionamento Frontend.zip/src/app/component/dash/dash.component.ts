import { Component, OnInit } from '@angular/core';
import {
  MatSort, MatPaginator, MatTableDataSource, MatTabChangeEvent, MatSnackBar
} from '@angular/material';

import { Patio } from '../../domain/patio';
import { Vaga } from '../../domain/vaga';
import { VagaStatus } from '../../domain/vaga-status';
import { Estacionamento } from '../../domain/estacionamento';
import { PatioService } from '../../service/patio.service';

@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent implements OnInit {

  currentTab = 0;
  patios: Patio[];

  constructor(
    private patioService: PatioService
  ) { }

  ngOnInit() {
    this.getPatios();
  }

  changeTab(tabChangeEvent: MatTabChangeEvent) {
    this.currentTab = tabChangeEvent.index;
  }

  getPatios(): void {
    this.patioService.findAll().subscribe (bf => {
      if(bf && bf.success) {
        this.patios = bf.list;
      }
    });
  }

  isDisponivel(status: VagaStatus) {
    return status.toString() == "DISPONIVEL" ? true : false;
  }

  isIndisponivel(status: VagaStatus) {
    return status.toString() == "INDISPONIVEL" ? true : false;
  }

  isOcupada(status: VagaStatus) {
    debugger;
    return status.toString() == "OCUPADA" ? true : false;
  }

}
