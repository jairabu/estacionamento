import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { GenericComponent } from '../generic.component';
import { Patio } from '../../domain/patio';
import { PatioService } from '../../service/patio.service';

@Component({
  selector: 'app-patio',
  templateUrl: './patio.component.html',
  styleUrls: ['./patio.component.css']
})
export class PatioComponent extends GenericComponent {

  constructor(
    private matSnackBar: MatSnackBar,
    private patioService: PatioService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Patio();
    this.entityService = this.patioService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['id', 'descricao', 'taxaHora'];
    super.loadAll();
  }

}
