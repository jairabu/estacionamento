import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { FormControl } from '@angular/forms';

import { GenericComponent } from '../generic.component';
import { Veiculo } from '../../domain/veiculo';
import { VeiculoService } from '../../service/veiculo.service';
import { Cor } from '../../domain/cor';
import { Modelo } from '../../domain/modelo';
import { Cliente } from '../../domain/cliente';
import { CorService } from '../../service/cor.service';
import { ModeloService } from '../../service/modelo.service';
import { ClienteService } from '../../service/cliente.service';

@Component({
  selector: 'app-veiculo',
  templateUrl: './veiculo.component.html',
  styleUrls: ['./veiculo.component.css']
})
export class VeiculoComponent extends GenericComponent {

  cores: Cor[];
  modelos: Modelo[];
  clientes: Cliente[];
  coresAutocomplete = new FormControl();
  modelosAutocomplete = new FormControl();
  clientesAutocomplete = new FormControl();

  constructor(
    private matSnackBar: MatSnackBar,
    private veiculoService: VeiculoService,
    private corService: CorService,
    private modeloService: ModeloService,
    private clienteService: ClienteService,
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Veiculo();
    this.entityService = this.veiculoService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['id', 'placa', 'modelo', 'cor', 'cliente'];
    super.loadAll();

    this.entities.sortingDataAccessor = (element, property) => {
      switch(property) {
        case 'modelo': return element.modelo ? element.modelo.nome : '';
        case 'cor': return element.cor ? element.cor.nome : '';
        case 'cliente': return element.cliente ? element.cliente.nome : '';
        default: return element[property];
      }
    };
  }

  loadAllAfter():void {
    this.getCores();
    this.getModelos();
    this.getClientes();
  }

  coresDisplay(cor?: Cor): string | undefined {
    return cor ? cor.nome : undefined;
  }

  modelosDisplay(modelo?: Modelo): string | undefined {
    return modelo ? modelo.nome : undefined;
  }

  clientesDisplay(cliente?: Cliente): string | undefined {
    return cliente ? cliente.nome : undefined;
  }

  getCores(): void {
    this.corService.findAll().subscribe (bf => {
      this.cores = super.getListFromBF(bf);
    });
  }

  getModelos(): void {
    this.modeloService.findAll().subscribe (bf => {
      this.modelos = super.getListFromBF(bf);
    });
  }

  getClientes(): void {
    this.clienteService.findAll().subscribe (bf => {
      this.clientes = super.getListFromBF(bf);
    });
  }
}
