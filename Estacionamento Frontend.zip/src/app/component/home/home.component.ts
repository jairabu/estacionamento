import {
  Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import {
  MatSort, MatPaginator, MatTableDataSource, MatTabChangeEvent, MatSnackBar
} from '@angular/material';
import { FormControl } from '@angular/forms';
import { Observable, Subject, pipe, of, from } from 'rxjs';
import { map, filter, scan } from 'rxjs/operators';
import { NgForm } from '@angular/forms';
import { DataSource } from '@angular/cdk/collections';

import {
  Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized
} from '@angular/router';

import { Global } from '../../util/globals';
import { Usuario } from '../../domain/usuario';
import { UsuarioService } from '../../service/usuario.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  entidade: Usuario;
  loading = {value: false};

  constructor(
    private router: Router,
    public snackBar: MatSnackBar,
    private usuarioService: UsuarioService
  ) { }

  ngOnInit() {
    this.entidade = new Usuario();
  }

  entrar(): void {
    Global.entrar(this.usuarioService, this.snackBar, this.router, this.loading, this.entidade.login, this.entidade.senha);
  }

}
