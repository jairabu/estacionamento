import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { GenericComponent } from '../generic.component';
import { Usuario } from '../../domain/usuario';
import { UsuarioService } from '../../service/usuario.service';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent extends GenericComponent {

  constructor(
    private matSnackBar: MatSnackBar,
    private usuarioService: UsuarioService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Usuario();
    this.entityService = this.usuarioService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['id', 'login', 'nome', 'telefone'];
    super.loadAll();
  }

}
