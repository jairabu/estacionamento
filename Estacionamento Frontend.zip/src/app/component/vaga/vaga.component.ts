import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { FormControl } from '@angular/forms';

import { GenericComponent } from '../generic.component';
import { Vaga } from '../../domain/vaga';
import { VagaService } from '../../service/vaga.service';
import { vagaStatus } from '../../domain/vaga-status';
import { Patio } from '../../domain/patio';
import { PatioService } from '../../service/patio.service';

@Component({
  selector: 'app-vaga',
  templateUrl: './vaga.component.html',
  styleUrls: ['./vaga.component.css']
})
export class VagaComponent extends GenericComponent {

  patios: Patio[];
  patiosAutocomplete = new FormControl();
  status: any;

  constructor(
    private matSnackBar: MatSnackBar,
    private vagaService: VagaService,
    private patioService: PatioService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Vaga();
    this.entityService = this.vagaService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['id', 'numero', 'patio', 'status'];
    this.status = vagaStatus;
    this.loadAll();

    this.entities.sortingDataAccessor = (element, property) => {
      switch(property) {
        case 'patio': return element.patio ? element.patio.descricao : '';
        default: return element[property];
      }
    };
  }

  loadAllAfter():void {
    this.getPatios();
  }

  patiosDisplay(patio?: Patio): string | undefined {
    return patio ? patio.descricao : undefined;
  }

  getPatios(): void {
    this.patioService.findAll().subscribe (bf => {
      this.patios = super.getListFromBF(bf);
    });
  }

}
