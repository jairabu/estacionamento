import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { GenericComponent } from '../generic.component';
import { Estacionamento } from '../../domain/estacionamento';
import { Veiculo } from '../../domain/veiculo';
import { Vaga } from '../../domain/vaga';
import { EstacionamentoService } from '../../service/estacionamento.service';
import { VeiculoService } from '../../service/veiculo.service';
import { VagaService } from '../../service/vaga.service';

@Component({
  selector: 'app-estacionamento',
  templateUrl: './estacionamento.component.html',
  styleUrls: ['./estacionamento.component.css']
})
export class EstacionamentoComponent extends GenericComponent {
  @ViewChild('idVagaSelect') idVagaSelect;

  veiculos: Veiculo[];
  vagas: Vaga[];
  veiculosAutocomplete = new FormControl();
  vagasAutocomplete = new FormControl();
  idVaga: number;
  idEstacionamento: number;

  constructor(
    private matSnackBar: MatSnackBar,
    private estacionamentoService: EstacionamentoService,
    private veiculoService: VeiculoService,
    private vagaService: VagaService,
    private route: ActivatedRoute
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Estacionamento();
    this.entityService = this.estacionamentoService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['entrada', 'saida', 'valorPago', 'veiculo', 'vaga'];
    super.loadAll();

    this.entities.sortingDataAccessor = (element, property) => {
      switch(property) {
        case 'veiculo': return element.veiculo ? element.veiculo.placa : '';
        case 'vaga': return element.vaga ? element.vaga.numero : '';
        default: return element[property];
      }
    };

    this.route.params.subscribe(params => {
      this.idEstacionamento = +params['idEstacionamento'];
      this.idVaga = +params['idVaga'];
      // Saida ou entrada de estacionamento
      if(this.idEstacionamento || this.idVaga) {
        this.currentTab = 1;
      }
    });
  }

  loadAllAfter():void {
    this.getVeiculos();
    this.getVagas();
  }

  findAllAfter():void {
    // Saída
    if(this.idEstacionamento) {
      var estacionamentoFiltrado: Estacionamento =
        this.entities.data.filter(estacionamento => estacionamento.id == this.idEstacionamento)[0];
      this.entity = estacionamentoFiltrado;
    }
  }

  veiculosDisplay(veiculo?: Veiculo): string | undefined {
    return veiculo ? veiculo.placa : undefined;
  }

  vagasDisplay(vaga?: Vaga): string | undefined {
    return vaga && vaga.numero ? vaga.numero.toString() : undefined;
  }

  getVeiculos(): void {
    this.veiculoService.findAll().subscribe (bf => {
      this.veiculos = super.getListFromBF(bf);
    });
  }

  getVagas(): void {
    this.vagaService.findAll().subscribe (bf => {
      this.vagas = super.getListFromBF(bf);
      // Entrada
      if(this.idVaga) {
        this.entity = new Estacionamento();
        var vagaFiltrada: Vaga = this.vagas.filter(vaga => vaga.id == this.idVaga)[0];
        this.entity.vaga = vagaFiltrada;
        this.idVagaSelect.nativeElement.value = this.entity.vaga.numero;
      }
    });
  }

  saveEntrada(): void {
    this.entity.entrada = new Date();
    super.save();
  }

  saveSaida(): void {
    this.entity.saida = new Date();
    super.update();
  }
}
