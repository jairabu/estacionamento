import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { GenericComponent } from '../generic.component';
import { Modelo } from '../../domain/modelo';
import { ModeloService } from '../../service/modelo.service';

@Component({
  selector: 'app-modelo',
  templateUrl: './modelo.component.html',
  styleUrls: ['./modelo.component.css']
})
export class ModeloComponent extends GenericComponent {

  constructor(
    private matSnackBar: MatSnackBar,
    private modeloService: ModeloService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Modelo();
    this.entityService = this.modeloService;
    this.snackBar = this.matSnackBar;
    super.loadAll();
  }

}
