import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { GenericComponent } from '../generic.component';
import { Cor } from '../../domain/cor';
import { CorService } from '../../service/cor.service';

@Component({
  selector: 'app-cor',
  templateUrl: './cor.component.html',
  styleUrls: ['./cor.component.css']
})
export class CorComponent extends GenericComponent {

  constructor(
    private matSnackBar: MatSnackBar,
    private corService: CorService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Cor();
    this.entityService = this.corService;
    this.snackBar = this.matSnackBar;
    super.loadAll();
  }

}
