import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { GenericComponent } from '../generic.component';
import { Cliente } from '../../domain/cliente';
import { ClienteService } from '../../service/cliente.service';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css']
})
export class ClienteComponent extends GenericComponent {

  constructor(
    private matSnackBar: MatSnackBar,
    private clienteService: ClienteService
  ) {
    super();
  }

  ngOnInit() {
    this.entityToCopy = new Cliente();
    this.entityService = this.clienteService;
    this.snackBar = this.matSnackBar;
    this.columnsDesktop = ['id', 'nome', 'cpf', 'telefone'];    
    super.loadAll();
  }

}
