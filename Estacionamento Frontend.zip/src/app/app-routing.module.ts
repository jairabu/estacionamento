import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AjudaComponent } from './component/ajuda/ajuda.component';
import { ClienteComponent } from './component/cliente/cliente.component';
import { CorComponent } from './component/cor/cor.component';
import { DashComponent } from './component/dash/dash.component';
import { EstacionamentoComponent } from './component/estacionamento/estacionamento.component';
import { HomeComponent } from './component/home/home.component';
import { ModeloComponent } from './component/modelo/modelo.component';
import { PatioComponent } from './component/patio/patio.component';
import { UsuarioComponent } from './component/usuario/usuario.component';
import { VagaComponent } from './component/vaga/vaga.component';
import { VeiculoComponent } from './component/veiculo/veiculo.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'ajuda', component: AjudaComponent },
  { path: 'cliente', component: ClienteComponent },
  { path: 'cor', component: CorComponent },
  { path: 'dash', component: DashComponent },
  { path: 'estacionamento/', component: EstacionamentoComponent },
  { path: 'estacionamento/save/:idVaga', component: EstacionamentoComponent },
  { path: 'estacionamento/update/:idEstacionamento', component: EstacionamentoComponent },
  { path: 'home', component: HomeComponent },
  { path: 'modelo', component: ModeloComponent },
  { path: 'patio', component: PatioComponent },
  { path: 'usuario', component: UsuarioComponent },
  { path: 'vaga', component: VagaComponent },
  { path: 'veiculo', component: VeiculoComponent },
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
