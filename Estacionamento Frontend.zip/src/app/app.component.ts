import { Component, Inject, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import {
  Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized
} from '@angular/router';

import { Global } from './util/globals';
import { Usuario } from './domain/usuario';
import { UsuarioService } from './service/usuario.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'Controle de Estacionamentos';
  isLogin = false;

  constructor(
    public snackBar: MatSnackBar,
    public router: Router,
    public usuarioService: UsuarioService
  ) {
    router.events.forEach((event) => {
      if(event instanceof NavigationEnd) {
        this.updateLogin()
      }
    });
  }

  ngOnInit() {
    this.updateLogin();
  }

  updateLogin(): void {
    this.isLogin = window.location.pathname === '/home' ||
      window.location.pathname === '/'? true : false;
  }

  isLogged(): boolean {
    if(Global.getUsuarioLogado()) {
      return true;
    }
    else {
      return false;
    }
  }

  sair(): void {
    Global.sair(this.snackBar);
  }

  /*
  entrar(): void {
    Global.entrar(this.usuarioService, this.snackBar, this.router, "teste", "teste");
  }*/

}
