import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, pipe, of, from } from 'rxjs';
import { map, tap, catchError, filter, scan } from 'rxjs/operators';

import { Global } from '../util/globals';
import { BackendFrontend } from '../domain/backend-frontend';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

export class GenericService {
  http: HttpClient;
  urlService: string;
  entityName: string;

  findEntity (idEntity: number): Observable<any> {
    const url = this.urlService+"/"+idEntity;
    return this.http.get<any>(url)
      .pipe(
        tap(entities => this.log(this.entityName+': findEntity')),
        catchError(this.handleError(this.entityName+': findEntity', []))
      );
  }

  findAll (): Observable<BackendFrontend> {
    return this.http.get<any>(this.urlService)
      .pipe(
        tap(entities => this.log(this.entityName+': findAll')),
        catchError(this.handleError(this.entityName+': findAll', []))
      );
  }

  save (entity: any): Observable<any> {
    return this.http.post<any>(this.urlService, entity, httpOptions).pipe(
      tap((entity: any) => this.log(this.entityName+': save')),
      catchError(this.handleError<any>(this.entityName+': save'))
    );
  }

  update (entity: any): Observable<any> {
    return this.http.put(this.urlService, entity, httpOptions).pipe(
      tap(_ => this.log(this.entityName+': update')),
      catchError(this.handleError<any>(this.entityName+': update'))
    );
  }

  delete (entity: any): Observable<any> {
    const url = this.urlService+"/"+entity.id;
    return this.http.delete<any>(url, httpOptions).pipe(
      tap(_ => this.log(this.entityName+': delete')),
      catchError(this.handleError<any>(this.entityName+': delete'))
    );
  }

  handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      this.log(operation+' falhou: '+error.message);
      return of(result as T);
    };
  }

  log(message: string) {
    console.log(message);
  }
}
