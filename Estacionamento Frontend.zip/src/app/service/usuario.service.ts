import {
  Injectable, Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, pipe, of, from } from 'rxjs';
import { map, tap, catchError, filter, scan } from 'rxjs/operators';

import { Global } from '../util/globals';
import { GenericService } from './generic.service';
import { BackendFrontend } from '../domain/backend-frontend';
import { Usuario } from '../domain/usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService extends GenericService {
  constructor(httpClient: HttpClient) {
    super();
    this.http = httpClient;
    this.urlService = Global.urlService+'/usuario';
    this.entityName = 'Usuário';
  }

  login (login: string, senha:string): Observable<BackendFrontend> {
    const url = this.urlService+"/login/"+login+"/"+senha;
    return this.http.get<any>(url)
      .pipe(
        tap(entities => this.log(this.entityName+': login')),
        catchError(this.handleError(this.entityName+': login', []))
      );
  }

  logout (usuario: Usuario): any {
    const url = this.urlService+"/logout/"+usuario.login;
    return this.http.get<any>(url)
      .pipe(
        tap(enitities => this.log(this.entityName+': logout')),
        catchError(this.handleError(this.entityName+': logout', []))
      );
  }
}
