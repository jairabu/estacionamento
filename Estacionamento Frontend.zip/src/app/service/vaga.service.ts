import {
  Injectable, Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Global } from '../util/globals';
import { GenericService } from './generic.service';
import { Vaga } from '../domain/vaga';

@Injectable({
  providedIn: 'root'
})
export class VagaService extends GenericService {
  constructor(httpClient: HttpClient) {
    super();
    this.http = httpClient;
    this.urlService = Global.urlService+'/vaga';
    this.entityName = 'Vaga';
  }
}
