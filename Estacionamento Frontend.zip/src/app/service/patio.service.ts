import {
  Injectable, Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Global } from '../util/globals';
import { GenericService } from './generic.service';
import { Patio } from '../domain/patio';

@Injectable({
  providedIn: 'root'
})
export class PatioService extends GenericService {
  constructor(httpClient: HttpClient) {
    super();
    this.http = httpClient;
    this.urlService = Global.urlService+'/patio';
    this.entityName = 'Pátio';
  }
}
