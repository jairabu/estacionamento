import {
  Injectable, Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Global } from '../util/globals';
import { GenericService } from './generic.service';
import { Cor } from '../domain/cor';

@Injectable({
  providedIn: 'root'
})
export class CorService extends GenericService {
  constructor(httpClient: HttpClient) {
    super();
    this.http = httpClient;
    this.urlService = Global.urlService+'/cor';
    this.entityName = 'Cor';
  }
}
