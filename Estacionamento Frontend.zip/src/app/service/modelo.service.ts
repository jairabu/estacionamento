import {
  Injectable, Component, OnInit, AfterViewInit, ViewChild
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Global } from '../util/globals';
import { GenericService } from './generic.service';
import { Modelo } from '../domain/modelo';

@Injectable({
  providedIn: 'root'
})
export class ModeloService extends GenericService {
  constructor(httpClient: HttpClient) {
    super();
    this.http = httpClient;
    this.urlService = Global.urlService+'/modelo';
    this.entityName = 'Modelo';
  }
}
